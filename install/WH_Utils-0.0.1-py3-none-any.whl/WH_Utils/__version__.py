"""
__version__.py
~~~~~~~~~~~~~~

Information about the current version of the py-package-template package.
"""

__title__ = "WH_Utils"
__description__ = "py-package-template - Package Template Project Generator"
__version__ = "0.0.1"
__author__ = "McClain Thiel"
__author_email__ = "mcclain@wealthawk.com"
__license__ = "Apache 2.0"
__url__ = ""
