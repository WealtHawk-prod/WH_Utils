# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['Coresignal',
 'WH_Utils',
 'WH_Utils.External',
 'WH_Utils.External.Coresignal',
 'WH_Utils.External.Typeform',
 'WH_Utils.Objects']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.0.1,<9.0.0',
 'numpydoc>=1.1.0,<2.0.0',
 'pandas>=1.3.4,<2.0.0',
 'pydantic>=1.8.2,<2.0.0',
 'requests>=2.26.0,<3.0.0',
 'sphinxcontrib-napoleon>=0.7,<0.8',
 'types-requests>=2.25.11,<3.0.0']

entry_points = \
{'console_scripts': ['WH_Utils = WH_Utils.__main__:main']}

setup_kwargs = {
    'name': 'wh-utils',
    'version': '0.0.2',
    'description': 'WH_Utils',
    'long_description': "Wh_Utils\n========\n\n\n|Read the Docs| |Tests| |Codecov|\n\n|pre-commit| |Black|\n\n\n.. |Read the Docs| image:: https://img.shields.io/badge/Docs-Here-blue.svg\n   :target: https://mcclain-thiel.github.io/WH_Utils/\n   :alt: Read the documentation at https://mcclain-thiel.github.io/WH_Utils/\n.. |Tests| image:: https://github.com/McClain-Thiel/WH_Utils/workflows/Tests/badge.svg\n   :target: https://github.com/McClain-Thiel/WH_Utils/actions?workflow=Tests\n   :alt: Tests\n.. |Codecov| image:: https://codecov.io/gh/McClain-Thiel/WH_Utils/branch/master/graph/badge.svg?token=ZJI9YLCSQ9\n   :target: :target: https://codecov.io/gh/McClain-Thiel/WH_Utils\n   :alt: Codecov\n.. |pre-commit| image:: https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white\n   :target: https://github.com/pre-commit/pre-commit\n   :alt: pre-commit\n.. |Black| image:: https://img.shields.io/badge/code%20style-black-000000.svg\n   :target: https://github.com/psf/black\n   :alt: Black\n\n\nWhat is it?\n---------------\n\nThe `WH_Utils` repo is meant to make development easier across the organization by standardizing the way\nwe interact with common objects. For example, there are modules for `Objects` that contain all enums used\nby the orgainization and a `Models` module that contains a powerful class based representation of common\nobjects. For more info on this check out the docs.\n\n\n\n\nCredits\n-------\n\nThis project was generated from `@cjolowicz`_'s `Hypermodern Python Cookiecutter`_ template.\n\n.. _@cjolowicz: https://github.com/cjolowicz\n.. _Cookiecutter: https://github.com/audreyr/cookiecutter\n.. _MIT license: https://opensource.org/licenses/MIT\n.. _PyPI: https://pypi.org/\n.. _Hypermodern Python Cookiecutter: https://github.com/cjolowicz/cookiecutter-hypermodern-python\n.. _file an issue: https://github.com/McClain-Thiel/WH_Utils/issues\n.. _pip: https://pip.pypa.io/\n.. github-only\n.. _Contributor Guide: CONTRIBUTING.rst\n.. _Usage: https://WH_Utils.readthedocs.io/en/latest/usage.html\n",
    'author': 'McClain Thiel',
    'author_email': 'mcclain@wealthawk.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/McClain-Thiel/WH_Utils',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7.1,<4.0.0',
}


setup(**setup_kwargs)
