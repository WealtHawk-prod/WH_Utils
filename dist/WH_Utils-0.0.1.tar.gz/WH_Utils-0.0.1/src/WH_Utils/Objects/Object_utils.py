import json
from typing import List, Union, Dict, Any



def verify_json(expected_class: str, json: Dict[str, Any]) -> None:
    """

    """
    return

def _verify_as_client(json: Dict[str, Any]) -> None:
    return

def _verify_as_company(json: Dict[str, Any]) -> None:
    return

def _verify_as_user(json: Dict[str, Any]) -> None:
    return

def _verify_as_event(json: Dict[str, Any]) -> None:
    return

def verify_auth_header(json: Dict[str, Any]) -> None:
    return

def _verify_coresignal_auth(json: Dict[str, Any]) -> None:
    return

def _verify_WH_auth(json: Dict[str, Any]) -> None:
    return
