

def test_func(this: str) -> str:
    """
    yall bozos
    """
